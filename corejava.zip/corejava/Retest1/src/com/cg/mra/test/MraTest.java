package com.cg.mra.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class MraTest {

	@Test
	public void test() {
	
	}

}
