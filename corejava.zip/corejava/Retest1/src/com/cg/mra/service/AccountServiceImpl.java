package com.cg.mra.service;

import java.util.regex.Pattern;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountNotFoundException;

public class AccountServiceImpl implements AccountService{
	AccountDao accountDao=new AccountDaoImpl();

	@Override
	public double getAccountDetail(String mobileNo) throws AccountNotFoundException {
		Account account=accountDao.getAccountDetail(mobileNo);
		if(account==null) throw new AccountNotFoundException("Mobile no does not Exist.");
		return account.getAccountBalance();
	}

	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		accountDao.rechargeAccount(mobileNo, rechargeAmount);
		rechargeAmount=140.00;
		double accountBalance=accountDao.rechargeAccount(mobileNo, rechargeAmount).getAccountBalance()-rechargeAmount;
		return accountBalance;
	}

	@Override
	public String getCustomerName(String mobileNo) {
		
		return accountDao.getCustomerName(mobileNo).getCustomerName();
	}
	
	}
	
		


