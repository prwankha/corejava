package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountNotFoundException;

public interface AccountService {
	double getAccountDetail(String mobileNo) throws AccountNotFoundException ;
	double rechargeAccount(String mobileNo,double rechargeAmount);
	String getCustomerName(String mobileNo); 
}
