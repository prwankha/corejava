package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {
	Account account=new Account();
	Map<String, Account> accounts;
	 public AccountDaoImpl() {
	accounts=new HashMap<String, Account>();
	accounts.put("88888", new Account("abhishek", "Saving", 1000.00));
	accounts.put("99999", new Account("abhi", "current", 2000.00));
	}
	@Override
	public Account getAccountDetail(String mobileNo) {
		return accounts.get(mobileNo);
	}
	@Override
	public Account rechargeAccount(String mobileNo, double rechargeAmount) {
		
		return accounts.get(mobileNo);
	}
	@Override
	public Account getCustomerName(String mobileNo) {
		
		return accounts.get(mobileNo);
	}

}
