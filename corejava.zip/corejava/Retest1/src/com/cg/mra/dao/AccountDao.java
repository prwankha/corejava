package com.cg.mra.dao;

import com.cg.mra.beans.Account;

public interface AccountDao {
	Account getAccountDetail(String mobileNo); 
	Account rechargeAccount(String mobileNo,double rechargeAmount);
	Account getCustomerName(String mobileNo);
}
