package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.exception.AccountNotFoundException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainClass {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		int choice;
		String mobileNo;
		double rechargeAmount,balance;
		AccountService accountService=new AccountServiceImpl(); 
		try {
		do {
			System.out.println("\n Enter your choice :");
			System.out.println("1.Account Balance Enquiry :");
			System.out.println("2.Recharge Account :");
			System.out.println("3. Exit");
			choice=scanner.nextInt();
			scanner.nextLine();
			switch (choice) {
			case 1:
				System.out.println("Enter your mobileNo :");
				mobileNo=scanner.nextLine();
				balance=accountService.getAccountDetail(mobileNo);
				System.out.print("Available balance :"+balance);
				break;
			case 2:
				System.out.println("Enter your mobileNo :");
				mobileNo=scanner.nextLine();
				scanner.nextLine();
				System.out.println("Enter rechargeAmount :");
				rechargeAmount=scanner.nextDouble();
				balance=accountService.rechargeAccount(mobileNo,rechargeAmount);
				System.out.print("Your account is recharged sucessfully.\n Hello "+accountService.getCustomerName(mobileNo)+" \n Available balance :"+balance);
				break;
			case 3:
				System.out.println("thank you");
				System.exit(0);
			default:
				System.out.println("enter valid choice :");
				break;
			}
		}while(choice!=3);
		}
		catch (AccountNotFoundException e) {
		e.printStackTrace();
		}
		}

}
