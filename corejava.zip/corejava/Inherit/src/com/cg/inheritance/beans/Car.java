package com.cg.inheritance.beans;

public class Car extends Vehicle {
private int noOfSeat;
private String carName,modelType;
public Car() {
	super();
	
}

public Car(int insurance, int regNo, String licensePlate,int noOfSeat,String carName,String modelType) {
	super(insurance, regNo, licensePlate);
	this.carName=carName;
	this.modelType=modelType;
	
}

public int getNoOfSeat() {
	return noOfSeat;
}

public void setNoOfSeat(int noOfSeat) {
	this.noOfSeat = noOfSeat;
}

public String getCarName() {
	return carName;
}

public void setCarName(String carName) {
	this.carName = carName;
}

public String getModelType() {
	return modelType;
}

public void setModelType(String modelType) {
	this.modelType = modelType;
}

}
