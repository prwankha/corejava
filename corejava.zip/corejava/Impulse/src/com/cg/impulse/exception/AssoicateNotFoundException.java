package com.cg.impulse.exception;

public class AssoicateNotFoundException {

}
