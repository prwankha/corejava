package com.cg.impulse.services;

import com.cg.impulse.Daoservices.AssociateDao;
import com.cg.impulse.Daoservices.AssociateDaoImpl;

public class AssoicateServicesImpl implements AssociateServices{
	private AssociateDao associate=new AssociateDaoImpl();
	@Override
	public int getDetails(String firstName, String lastName) {
		associate.save(associate);
		return associate;
	}

}
