package com.cg.impulse.services;

public interface AssociateServices {
	int getDetails(String firstName,String lastName);

}
