package com.cg.impulse.Daoservices;
import com.cg.impulse.beans.*;
import java.util.List;

public interface AssociateDao {
	Associate save(AssociateDao associate);
	Associate findOne(int associateId);
	

}
