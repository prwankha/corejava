package com.cg.enquiry.client;

import java.util.Scanner;

import com.cg.enquiry.service.EnquiryService;
import com.cg.enquiry.service.EnquiryServiceImpl;

public class MainClass {
	public static void main(String args[]) {
		EnquiryService enquiryService=new EnquiryServiceImpl();
		Scanner scanner=new Scanner(System.in);
		int choice,contactNumber,customerId;
		String firstName,lastName,prefferedDomain,prefferedLocation;
		do {
			System.out.println(" Choose an operation ");
			System.out.println("1.Enter Enquiry Details ");
			System.out.println("2.View Enquiry Details on Id ");
			System.out.println("3. Exit ");
			choice = scanner.nextInt();
			scanner.nextLine();
			try {
				switch (choice) {
				case 1:
					System.out.println("Enter First Name :");
					firstName=scanner.nextLine();
					System.out.println("Enter Last Name :");
					lastName=scanner.nextLine();
					System.out.println("Enter Contact Number :");
					contactNumber=scanner.nextInt();
					scanner.nextLine();
					System.out.println("Enter Preffered Domain :");
					prefferedDomain=scanner.nextLine();
					System.out.println("Enter Preffered Location :");
					prefferedLocation=scanner.nextLine();
					customerId=enquiryService.saveCustomerDetail(firstName,lastName,contactNumber,prefferedDomain,prefferedLocation);
					System.out.println("your Id is :"+customerId);
					break;
				case 2:
					System.out.println("Enter customerId :");
					customerId=scanner.nextInt();
					System.out.println("Enquiry Detail are :"+enquiryService.viewEnquiryDetail(customerId));
					break;
				case 3:
					System.out.println("Thank you");
					System.exit(0);
				default:
					System.out.println("Enter valid choice");
					break;
				}
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}while(choice!=3);
	}
}
