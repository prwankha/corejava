package com.cg.enquiry.beans;

public class Customer {
private String firstName,lastName,custDomain,custLoc;
private int custId,contactNo;
public Customer() {}
public Customer(String firstName, String lastName, String custDomain, String custLoc, int custId, int contactNo) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.custDomain = custDomain;
	this.custLoc = custLoc;
	this.custId = custId;
	this.contactNo = contactNo;
}

public Customer(String firstName, String lastName, String custDomain, String custLoc, int contactNo) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
	this.custDomain = custDomain;
	this.custLoc = custLoc;
	this.contactNo = contactNo;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getCustDomain() {
	return custDomain;
}
public void setCustDomain(String custDomain) {
	this.custDomain = custDomain;
}
public String getCustLoc() {
	return custLoc;
}
public void setCustLoc(String custLoc) {
	this.custLoc = custLoc;
}
public int getCustId() {
	return custId;
}
public void setCustId(int custId) {
	this.custId = custId;
}
public int getContactNo() {
	return contactNo;
}
public void setContactNo(int contactNo) {
	this.contactNo = contactNo;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + contactNo;
	result = prime * result + ((custDomain == null) ? 0 : custDomain.hashCode());
	result = prime * result + custId;
	result = prime * result + ((custLoc == null) ? 0 : custLoc.hashCode());
	result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
	result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (contactNo != other.contactNo)
		return false;
	if (custDomain == null) {
		if (other.custDomain != null)
			return false;
	} else if (!custDomain.equals(other.custDomain))
		return false;
	if (custId != other.custId)
		return false;
	if (custLoc == null) {
		if (other.custLoc != null)
			return false;
	} else if (!custLoc.equals(other.custLoc))
		return false;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	if (lastName == null) {
		if (other.lastName != null)
			return false;
	} else if (!lastName.equals(other.lastName))
		return false;
	return true;
}
@Override
public String toString() {
	return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", custDomain=" + custDomain + ", custLoc="
			+ custLoc + ", custId=" + custId + ", contactNo=" + contactNo + "]";
}


}
