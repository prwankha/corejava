package com.cg.enquiry.dao;

import com.cg.enquiry.beans.Customer;

public interface EnquiryDao {
int saveCustomerDetail(Customer customer);
Customer viewEnquiryDetail(int customerId);
}
