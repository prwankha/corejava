package com.cg.enquiry.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.enquiry.beans.Customer;

public class EnquiryDaoImpl implements EnquiryDao  {
Map<Integer, Customer> customers;
public static int CUSTOMER_ID=0;
public EnquiryDaoImpl() {
	customers=new HashMap<Integer,Customer>();
}
@Override
public int saveCustomerDetail(Customer customer) {
	customer.setCustId(++CUSTOMER_ID);
	customers.put(customer.getCustId(), customer);
	return customer.getCustId();
}
@Override
public Customer viewEnquiryDetail(int customerId) {
	return customers.get(customerId);
	
}
	

}
