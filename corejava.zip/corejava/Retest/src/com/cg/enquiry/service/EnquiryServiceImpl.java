package com.cg.enquiry.service;

import com.cg.enquiry.beans.Customer;
import com.cg.enquiry.dao.EnquiryDao;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.exception.InvalidIdException;

public class EnquiryServiceImpl implements EnquiryService{
	EnquiryDao daoServices=new EnquiryDaoImpl(); 
	@Override
	public int saveCustomerDetail(String firstName, String lastName, int contactNumber, String prefferedDomain,
			String prefferedLocation) {
		Customer customer=new Customer(firstName, lastName, prefferedDomain, prefferedLocation, contactNumber);
		daoServices.saveCustomerDetail(customer);
		return customer.getCustId();
	}
	
	@Override
	public Customer viewEnquiryDetail(int customerId)  throws InvalidIdException{
		if(daoServices.viewEnquiryDetail(customerId)==null) throw new InvalidIdException(); 
		return daoServices.viewEnquiryDetail(customerId);
	}

}
