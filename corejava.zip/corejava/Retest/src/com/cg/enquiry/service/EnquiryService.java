package com.cg.enquiry.service;

import com.cg.enquiry.beans.Customer;
import com.cg.enquiry.exception.InvalidIdException;

public interface EnquiryService {
int saveCustomerDetail(String firstName,String lastName,int contactNumber,String prefferedDomain,String prefferedLocation);
Customer viewEnquiryDetail(int customerId) throws InvalidIdException;
}
