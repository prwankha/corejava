package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class PizzaOrderDAO implements IPizzaOrderDAO {

	public static Map<Integer, PizzaOrder> pizzaEntry = new HashMap<Integer, PizzaOrder>();

	public static Map<Integer, Customer> customerEntry = new HashMap<Integer, Customer>();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {
		customerEntry.put(customer.getCustomerId(), customer);
		pizzaEntry.put(pizza.getOrderId(), pizza);
		return 1;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		return pizzaEntry.get(orderId);
	}
}