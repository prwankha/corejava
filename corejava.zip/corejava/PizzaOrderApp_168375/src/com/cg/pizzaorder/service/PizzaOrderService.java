package com.cg.pizzaorder.service;

import java.util.regex.Pattern;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.InvalidOrderIdException;
import com.cg.pizzaorder.exception.InvalidPhoneNumberException;
import com.cg.pizzaorder.exception.InvalidToppingException;

public class PizzaOrderService implements IPizzaOrderService {

	private IPizzaOrderDAO pizzaOrderDAO = new PizzaOrderDAO();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws InvalidPhoneNumberException, InvalidToppingException {
		int orderId, customerId;
		double totalPrice;
		customerId = (int) (Math.random() * 5000);
		customer.setCustomerId(customerId);// cust complete

		orderId = (int) (Math.random() * 10000);
		pizza.setCustomerId(customerId);
		pizza.setOrderId(orderId);

		totalPrice = calPizzaPrice(pizza);
		pizza.setTotalPrice(totalPrice);

		if (valPhone(customer) != true)
			throw new InvalidPhoneNumberException();
		pizzaOrderDAO.placeOrder(customer, pizza);
		return pizza.getOrderId();
	}

	public double calPizzaPrice(PizzaOrder pizza) throws InvalidToppingException {
		double totalPrice = 0, basePrice = 350, toppingCost = 0;
		// calculation
		if (pizza.getTopping().equalsIgnoreCase("Capsicum"))
			toppingCost = 30;
		else if (pizza.getTopping().equalsIgnoreCase("Mushroom"))
			toppingCost = 50;
		else if (pizza.getTopping().equalsIgnoreCase("Jalapeno"))
			toppingCost = 70;
		else if (pizza.getTopping().equalsIgnoreCase("Paneer"))
			toppingCost = 85;
		else
			throw new InvalidToppingException();
		totalPrice = basePrice + toppingCost;
		return totalPrice;
	}

	public boolean valPhone(Customer customer) {
		if (Pattern.matches("[0-9]{10}", customer.getPhone()))
			return true;
		else
			return false;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws InvalidOrderIdException {
		if (pizzaOrderDAO.getOrderDetails(orderId) == null)
			throw new InvalidOrderIdException();
		else
			return pizzaOrderDAO.getOrderDetails(orderId);
	}
}