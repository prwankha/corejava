package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.InvalidOrderIdException;
import com.cg.pizzaorder.exception.InvalidPhoneNumberException;
import com.cg.pizzaorder.exception.InvalidToppingException;

public interface IPizzaOrderService {
	public int placeOrder(Customer customer, PizzaOrder pizza)
			throws InvalidPhoneNumberException, InvalidToppingException;

	public PizzaOrder getOrderDetails(int orderId) throws InvalidOrderIdException;
}