package com.cg.pizzaorder.test;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.InvalidOrderIdException;
import com.cg.pizzaorder.exception.InvalidPhoneNumberException;
import com.cg.pizzaorder.exception.InvalidToppingException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class PizzaOrderTest {

	private static IPizzaOrderService pizzaOrderService;

	@BeforeClass
	public static void setUpTestEnv() {
		pizzaOrderService = new PizzaOrderService();
	}

	@Before
	public void setUpTestData() {
		Customer customer = new Customer(101, "Moreshwar", "Pune", "9665178256");
		PizzaOrderDAO.customerEntry.put(101, customer);

		PizzaOrder pizzaOrder = new PizzaOrder(5001, 101, "Mushroom", 400);
		PizzaOrderDAO.pizzaEntry.put(5001, pizzaOrder);
	}

	@Test(expected = InvalidPhoneNumberException.class)
	public void testPlaceOrderForInvalidPhone() throws InvalidPhoneNumberException, InvalidToppingException {
		pizzaOrderService.placeOrder(new Customer("Amit", "Satara", "9870"), new PizzaOrder("Paneer"));
	}

	@Test(expected = InvalidToppingException.class)
	public void testPlaceOrderForInvalidTopping() throws InvalidPhoneNumberException, InvalidToppingException {
		pizzaOrderService.placeOrder(new Customer("Onkar", "Jalgaon", "9923239371"), new PizzaOrder("Tomato"));
	}

	@Test(expected = InvalidOrderIdException.class)
	public void testGetOrderDetailsForInvalidOrderId() throws InvalidOrderIdException {
		pizzaOrderService.getOrderDetails(912);
	}

	/*
	 @Test public void testGetOrderDetailsForValidOrderId() throws
	  InvalidOrderIdException { PizzaOrder expectedPizzaOrder=new PizzaOrder(110,
	  90, "Mushroom", 400); PizzaOrder
	  actualPizzaOrder=pizzaOrderService.getOrderDetails(110);
	  Assert.equals(expectedPizzaOrder, actualPizzaOrder); }
	 */

	@After
	public void tearDownTestData() {
		PizzaOrderDAO.customerEntry.clear();
	}

	@AfterClass
	public static void tearDownTestEnv() {
		pizzaOrderService = null;
	}
}