package com.cg.calculator.client;
import com.cg.calculator.exceptions.*;
import com.cg.calculator.services.*;
public class MainClass {

	public static void main(String[] args) throws InvalidNumberRangeException {
		MathServices mathServices=new MathServicesImpl1();
	
			System.out.println(mathServices.add(3, 4));
			System.out.println(mathServices.sub(5, 4));
			System.out.println(mathServices.mul(6, 3));	
		} 
		
	}


