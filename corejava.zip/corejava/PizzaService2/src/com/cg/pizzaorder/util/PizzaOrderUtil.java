package com.cg.pizzaorder.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
public class PizzaOrderUtil {
	public static Map<Integer, PizzaOrder>pizzaEntry = new HashMap<>();
	public static Map<Integer, Customer>customerEntry = new HashMap<>();
	public static Random rand = new Random();
	public static int getOrder_ID() {
		int ORDER_ID=rand.nextInt(2000);
		return ORDER_ID;
	}
	public static int getCustomer_ID() {
		int CUSTOMER_ID=rand.nextInt(1000);
		return CUSTOMER_ID;
	}
}
