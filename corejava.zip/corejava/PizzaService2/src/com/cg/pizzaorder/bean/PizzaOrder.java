package com.cg.pizzaorder.bean;

public class PizzaOrder {
	private int orderId,customerId;
	private double TotalPrice;
	public PizzaOrder() {}
	public PizzaOrder(double totalPrice) {
		super();
		TotalPrice = totalPrice;
	}
	public PizzaOrder(int customerId, double totalPrice) {
		super();
		this.customerId = customerId;
		TotalPrice = totalPrice;
	}
	public PizzaOrder(int orderId, int customerId, double totalPrice) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		TotalPrice = totalPrice;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return TotalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		TotalPrice = totalPrice;

	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(TotalPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + customerId;
		result = prime * result + orderId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PizzaOrder other = (PizzaOrder) obj;
		if (Double.doubleToLongBits(TotalPrice) != Double.doubleToLongBits(other.TotalPrice))
			return false;
		if (customerId != other.customerId)
			return false;
		if (orderId != other.orderId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PizzaOrder [orderId=" + orderId + ", customerId=" + customerId + ", TotalPrice=" + TotalPrice + "]";
	}

}