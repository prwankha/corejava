package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.PizzaOrderUtil;
public class PizzaOrderDAO implements IPizzaOrderDAO {
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza,int customerId) throws PizzaException {
		PizzaOrderUtil.customerEntry.put(customerId, customer);
		int orderId = PizzaOrderUtil.getOrder_ID();
		PizzaOrderUtil.pizzaEntry.put(orderId, pizza);
		return orderId;
	}
	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		return PizzaOrderUtil.pizzaEntry.get(orderId);
	}
}



