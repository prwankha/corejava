package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.*;
import com.cg.pizzaorder.dao.*;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.PizzaOrderUtil;
public class PizzaOrderService implements IPizzaOrderService {
	IPizzaOrderDAO pizzaOrderDao = new PizzaOrderDAO();
	@Override
	public int placeOrder(String customerName, String address, String phone,int price) throws PizzaException {
		PizzaOrder pizza = new PizzaOrder();
		int customerId = PizzaOrderUtil.getCustomer_ID();
		pizza.setCustomerId(customerId);
		int orderId = pizzaOrderDao.placeOrder(new Customer(customerName, address, phone),new PizzaOrder(pizza.getCustomerId(), price),customerId);
		return orderId;
	}
	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		return pizzaOrderDao.getOrderDetails(orderid);
	}	
}



