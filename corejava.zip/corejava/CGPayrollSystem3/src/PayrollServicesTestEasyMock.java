import static org.junit.Assert.*;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollservices.PayrollServices;
import com.cg.payroll.payrollservices.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
private static PayrollServices payrollServices;
private static AssociateDAO mockAssociateDao;

@BeforeClass
public static void setUpTestEnv() {
	mockAssociateDao=EasyMock.mock(AssociateDAO.class);
	payrollServices=new PayrollServicesImpl(mockAssociateDao);
}
@Before
public void setUpTestMockData() {
	Associate associate1=new Associate(101, 5000, "aaa", "bbb", "CCC", "a1", "SDSGR", "FFSFG",new Salary(10000, 100, 100), new BankDetails(233545, "gffe3", "hdfc"));
	Associate associate2=new Associate(102, 6000, "aba", "bcb", "dCC", "a2", "dDSGR", "adFSFG",new Salary(20000, 200, 200), new BankDetails(233546, "gffe4", "hdfc"));
	Associate associate3=new Associate(103, 7000, "aca", "bdb", "eCC", "a3", "eDSGR", "bdFSFG",new Salary(30000, 300, 300), new BankDetails(233547, "gffe5", "hdfc"));
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(12345)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);

}
@Test(expected= AssociateDetailsNotFoundException.class)
public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException    {
    payrollServices.getAssociateDetails(12345);
    EasyMock.verify(mockAssociateDao.findOne(12345));
}
@Test(expected= AssociateDetailsNotFoundException.class)
public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException  {
    Associate expectedAssociate= new Associate(101, 5000, "aaa", "bbb", "CCC", "a1", "SDSGR", "FFSFG",new Salary(10000, 100, 100), new BankDetails(233545, "gffe3", "hdfc"));
    Associate actualAssociate= payrollServices.getAssociateDetails(101);
    EasyMock.verify(mockAssociateDao.findOne(101));
    assertEquals(expectedAssociate, actualAssociate);
}
@After
public void tearDownTestMockData() {
	EasyMock.resetToDefault(mockAssociateDao);
}
@AfterClass
public static void tearDownTestEnv()    {
    mockAssociateDao= null;
    payrollServices= null;      
}

}






