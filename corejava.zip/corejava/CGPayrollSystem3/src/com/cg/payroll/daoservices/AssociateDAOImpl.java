package com.cg.payroll.daoservices;

import java.util.List;
import java.util.ArrayList;
import com.cg.payroll.beans.*;
import com.cg.payroll.util.PayrollUtil;
public class AssociateDAOImpl implements AssociateDAO{
    @Override
    public Associate save(Associate associate) {
        associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
        PayrollUtil.associate.put(associate.getAssociateID(), associate);
        return associate;
    }
    @Override
    public boolean update(Associate associate) {
        PayrollUtil.associate.put(associate.getAssociateID(),associate);
        return true;
    }
    @Override
    public Associate findOne(int associateId) {
        return PayrollUtil.associate.get(associateId);
    }
    @Override
    public List<Associate> findAll() {
        return new ArrayList<>(PayrollUtil.associate.values());
    }

}
