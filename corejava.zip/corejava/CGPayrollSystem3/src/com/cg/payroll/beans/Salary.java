package com.cg.payroll.beans;

public class Salary {
	public int basicpay,pf,epf,hra,pa,ca,oa,annualSalary,grossSalary,mothlyGross,totalSalary;

	public Salary() {
		super();
	}
	
	

	public Salary(int basicpay, int pf, int epf) {
		super();
		this.basicpay = basicpay;
		this.pf = pf;
		this.epf = epf;
	}



	public Salary(int basicpay, int pf, int epf, int hra, int pa, int ca, int oa, int annualSalary, int grossSalary,
			int mothlyGross) {
		super();
		this.basicpay = basicpay;
		this.pf = pf;
		this.epf = epf;
		this.hra = hra;
		this.pa = pa;
		this.ca = ca;
		this.oa = oa;
		this.annualSalary = annualSalary;
		this.grossSalary = grossSalary;
		this.mothlyGross = mothlyGross;
		this.totalSalary=totalSalary;
	}
	
	
	public int getBasicpay() {
		return basicpay;
	}

	public void setBasicpay(int basicpay) {
		this.basicpay = basicpay;
	}

	public int getPf() {
		return pf;
	}

	public void setPf(int pf) {
		this.pf = pf;
	}

	public int getEpf() {
		return epf;
	}

	public void setEpf(int epf) {
		this.epf = epf;
	}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getPa() {
		return pa;
	}

	public void setPa(int pa) {
		this.pa = pa;
	}

	public int getCa() {
		return ca;
	}

	public void setCa(int ca) {
		this.ca = ca;
	}

	public int getOa() {
		return oa;
	}

	public void setOa(int oa) {
		this.oa = oa;
	}

	public int getAnnualSalary() {
		return annualSalary;
	}

	public void setAnnualSalary(int annualSalary) {
		this.annualSalary = annualSalary;
	}

	public int getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(int grossSalary) {
		this.grossSalary = grossSalary;
	}

	public int getMothlyGross() {
		return mothlyGross;
	}

	public void setMothlyGross(int mothlyGross) {
		this.mothlyGross = mothlyGross;
	}

	public int gettotalSalary() {
		return totalSalary;
	}

	public void settotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;

}
}
