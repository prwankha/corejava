package com.cg.payroll.beans;

public class BankDetails {
    private int accountNo;
    private String ifsc,bankName;
    public BankDetails() {
        super();
    }
    public BankDetails(int accountNo, String ifsc, String bankName) {
        super();
        this.accountNo = accountNo;
        this.ifsc = ifsc;
        this.bankName = bankName;
    }
    public int getAccountNo() {
        return accountNo;
    }
    public void setAccountNo(int accountNo) {
        this.accountNo = accountNo;
    }
    public String getIfsc() {
        return ifsc;
    }
    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }
    public String getBankName() {
        return bankName;
    }
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

}
