package com.cg.payroll.client;
import java.util.Scanner;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.payrollservices.PayrollServices;
import com.cg.payroll.payrollservices.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException {
		PayrollServices payrollServices = new PayrollServicesImpl();
		Scanner sc=new Scanner(System.in);
		String firstName,lastName,department,designation,pancard,emailId,ifsc,bankName;
		int associateId = 0,ch=0,yearlyInvestmentUnder80C,basicPay,epf,pf,accountNo;
		System.out.println("Associate Management");
		do {
			System.out.println("1.Add associate");
			System.out.println("2.Find associate");
			System.out.println("3.Display all associate");
			System.out.println("4.Calculate associate salary");
			System.out.println("5.Exit");
			System.out.println("Enter your choice:");
			ch=sc.nextInt();
			switch (ch) {
			case 1:
				System.out.print("Enter new associate detail");
				System.out.println("firstName: ");
				firstName=sc.next();
				System.out.print("lastName: ");
				lastName=sc.next();
				System.out.print("yearlyInvestmentUnder80C: ");
				yearlyInvestmentUnder80C=sc.nextInt();
				System.out.print("Department: ");
				department=sc.next();
				System.out.print("designation: ");
				designation=sc.next();
				System.out.print("pancard no: ");
				pancard=sc.next();
				System.out.print("emailId: ");
				emailId=sc.next();
				System.out.print("basicPay: ");
				basicPay=sc.nextInt();
				System.out.print("epf: ");
				epf=sc.nextInt();
				System.out.print("pf: ");
				pf=sc.nextInt();
				System.out.print("accountNo: ");
				accountNo=sc.nextInt();
				System.out.print("ifsc: ");
				ifsc=sc.next();
				System.out.print("bankName: ");
				bankName=sc.next();
				
				associateId=payrollServices.acceptAssociatedetails(firstName, lastName, yearlyInvestmentUnder80C, department, designation, pancard, emailId, basicPay, epf, pf, accountNo, ifsc, bankName);
				System.out.println("Associate id : "+associateId);
				break;
			case 2:
				System.out.println("Enter associateId to search");
				associateId=sc.nextInt();
				try {
					System.out.println("Associate details: \n"+payrollServices.getAssociateDetails(associateId).toString());
				}
				catch(AssociateDetailsNotFoundException e) {
					e.printStackTrace();
				}
				
				break;
			case 3:
				try {
					System.out.println("Associate salary : \n"+payrollServices.getAssociateDetails(associateId).toString());
				}
				catch(AssociateDetailsNotFoundException e) {
					e.printStackTrace();
				}
					break;
					case 4:
				System.out.println("Exit");	
				System.exit(0);
				default:
					System.out.println("Invalid choice");
					break;
			}
			}while(ch!=4);
			
		}
		/*try {
			PayrollServices payrollServices = new PayrollServicesImpl();

			 associateId = payrollServices.acceptAssociatedetails("psw", "ww", 5000, "cse", "analyst", "11adsd", "ASDf@gmail.com", 50000, 1000, 1000, 12345, "0875", "hdfc");
			System.out.println("Associate id : "+associateId);
			System.out.println(payrollServices.getAssociateDetails(associateId));


			System.out.println(payrollServices.calculateNetSalary(associateId));


		}
		catch(Exception e) {
			e.printStackTrace();
		}*/
	}
