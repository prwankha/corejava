package com.cg.equality.client;

import com.cg.equality.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		Associate asc=new Associate("aaa", "www", "11000", 111, 5000);
		Associate asc1=new Associate("aaa", "www", "11000", 111, 5000);
		if(asc.equals(asc1))
			System.out.println("equal");
		else
			System.out.println("not equal");
		
		if(asc==asc1)
			System.out.println("equal");
		else
			System.out.println("not equal");
	}

}
