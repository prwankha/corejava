package com.cg.payroll.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.util.PayrollUtil;

public class AssociateDAOImpl implements AssociateDAO{
    
    @Override
    public Associate save(Associate associate) {
        associate.setAssociateID(PayrollUtil.getASSOCIATE_ID_COUNTER());
        PayrollUtil.associates.put(associate.getAssociateID(),associate);
        return associate;
    }
    @Override
    public boolean update(Associate associate) {
    	PayrollUtil.associates.put(associate.getAssociateID(),associate);
        return true;
    }
    @Override
    public Associate findOne(int associateId) {
    	return PayrollUtil.associates.get(associateId);
    }
   
	
	@Override
    public  List<Associate> findAll() {
		
        return new ArrayList<>(PayrollUtil.associates.values());
        
        
    }

}
