package com.cg.doctor.services;

import com.cg.doctor.bean.DoctorAppointment;

public interface DoctorAppointmentService{ 

	 int addDoctorAppointmentDetail(DoctorAppointment doctorAppointment);
	 DoctorAppointment getDoctorAppointmentDetail(int appointmentId);
}
