package com.cg.pizzaorder.ui;

import java.util.Scanner;

import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
public class Client {
	public static void main(String[] args) {
		IPizzaOrderService iPizzaOrderService = new PizzaOrderService();
		Scanner scanner=new Scanner(System.in);
		System.out.println("Pizza Order");
		int ch,customerId,price,pizzaTopping,orderDate;
		String customerName, address, phone;
		do {
			System.out.println("1.Place Order");
			System.out.println("2.Display Order");
			System.out.println("3.Exit");
			System.out.println("Enter your choice:");
			ch=scanner.nextInt();
		    scanner.nextLine();
			switch(ch) {
			case 1:
				System.out.print("Enter customer Name :");
				customerName=scanner.nextLine();
				System.out.println("Enter customer address : ");
				address=scanner.nextLine();
				System.out.println("Enter customer phone number : ");
				phone=scanner.nextLine();
				System.out.println("Price : ");
				price = scanner.nextInt();
				System.out.println("Order Date : ");
				orderDate=scanner.nextInt();
				try {
					customerId=iPizzaOrderService.placeOrder(customerName, address, phone);
				} catch (PizzaException e) {
				
					e.printStackTrace();
				}
				break;
			case 2:
				
				System.out.println("Pizza order sucessfully place with order id : "+customerId);
			case 3:
				System.out.println("Exit");	
				System.exit(0);
				break;
			}
		}while(ch!=3);
		}
		
		
	}



