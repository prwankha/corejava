package com.cg.pizzaorder.util;
import java.util.Map;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;



public class PizzaOrderUtil {
	public static Map<Integer, PizzaOrder>pizzaEntry;
	public static Map<Integer, Customer>customerEntry;
	
	public static int CUSTOMER_ID=100,ORDER_ID=2000;
	public static int getOrder_ID_COUNTER() {
		return ++ORDER_ID;
	}
	public static int getCustomer_ID_COUNTER() {

		return ++CUSTOMER_ID;
	}

}
