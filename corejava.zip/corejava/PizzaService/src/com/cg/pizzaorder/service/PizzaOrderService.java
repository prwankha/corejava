package com.cg.pizzaorder.service;

import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.*;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.ui.Client;


public class PizzaOrderService implements IPizzaOrderService {

	private IPizzaOrderDAO IpizzaOrderdao=new PizzaOrderDAO();

	@Override
	public int placeOrder(String custName,String address,String phone) throws PizzaException {
		Customer customer=new Customer("John","Dallas","9768587350");
		int price=0;
		int billId = 0;
		if( billId==customer.getCustomerId())
		{
			price=price+350;
			if(Client.choice==1)
				price=price+30;
			else if(Client.choice==2)
				price=price+50;
			else if(Client.choice==3)
				price=price+70;
			else
				price=price+85;
		}
		return price;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {

		PizzaOrder pizzaorder=this.getOrderDetails(orderid);
		if(orderid==0)throw new PizzaException("Orderid not Found");
		if(orderid==pizzaorder.getOrderId())
		{
			if(Client.choice==1)
				System.out.println("Toping is of Capcicum");
			else if(Client.choice==2)
				System.out.println("Toping is of Mushroom");
			else if(Client.choice==3)
				System.out.println("Toping is of Jalapeno");
			else
				System.out.println("Toping is of Paneer");
		}

		return pizzaorder;
	}
}


