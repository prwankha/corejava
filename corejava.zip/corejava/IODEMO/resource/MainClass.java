import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class MainClass {
public static void main(String args[]) {
	
try {
	Properties projectProperties=new Properties();
	projectProperties.load(new FileInputStream(".\\resource\\project_properties"));
	String var1=projectProperties.getProperty("key1");
	System.out.println(var1);
} catch (FileNotFoundException e) {
	
	e.printStackTrace();
} catch (IOException e) {
	
	e.printStackTrace();
}


}
}