package com.cg.serialization.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.iodemo.beans.ObjectSerializationDemo;
import com.cg.iodemo.beans.ReadWriteDemo;

public class MainClass {

	public static void main(String[] args) {
		
		 try {
			
			File file=new File("D:\\prwankha_prajwal_wankhade\\abc.txt");
			ObjectSerializationDemo.doSerialization(file);
			ObjectSerializationDemo.doDESerialization(file);
		
			 
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
}
