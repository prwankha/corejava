package com.cg.iodemo.beans;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectSerializationDemo {
	public static void doSerialization(File file) throws FileNotFoundException,IOException{
		Associate associate=new Associate(111, 10000, "aaa", "www");
		try(ObjectOutputStream destWriter=new ObjectOutputStream(new FileOutputStream(file))){
			destWriter.writeObject(associate);
			System.out.println("Associate object written on "+file.getAbsolutePath());
		}
	}
	public static void doDESerialization(File file) throws FileNotFoundException,IOException,ClassNotFoundException{
		try(ObjectInputStream srcReader=new ObjectInputStream(new FileInputStream(file))){
			Associate associate=(Associate)srcReader.readObject();
			System.out.println(associate);
		
		}
	
}
}
