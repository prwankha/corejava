package com.cg.iodemo.beans;
import java.io.File;
import java.io.IOException;



public class MainClass {
	public static void main (String args[]) {
			File fromFile=new File("D:\\prwankha_prajwal_wankhade\\abc.txt");
			File toFile=new File("d:\\"+fromFile.getName());
			try {
				//ReadWriteDemo.byteReadWriteDemo(fromFile, toFile);
				ReadWriteDemo.characterReadWrite(fromFile, toFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
	}

}
