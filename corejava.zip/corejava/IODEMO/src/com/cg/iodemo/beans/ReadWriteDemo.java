package com.cg.iodemo.beans;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadWriteDemo {
public static void byteReadWriteDemo(File fromFile,File toFile) throws IOException{
	try(BufferedInputStream srcReader= new BufferedInputStream(new FileInputStream(fromFile))){
		try(BufferedOutputStream destWriter= new BufferedOutputStream(new FileOutputStream(toFile))){
			//1st way
			/*int i=0;
			 * while((i=srcReader.readLine())!=-1)
			 * destWriter.writer(i);*/
			
			//2nd way
			
			 
			byte[] bufferData=new byte[(int)fromFile.length()];
			srcReader.read(bufferData);
			destWriter.write(bufferData);
			System.out.println("File written on "+toFile.getAbsolutePath());
		}
	}
	
}



public static void characterReadWrite(File fromFile,File toFile) throws FileNotFoundException,IOException{
	try(BufferedReader srcReader= new BufferedReader(new FileReader(fromFile))){
		try(BufferedWriter destWriter = new BufferedWriter(new FileWriter(toFile))){
			String data="";
			//while((data=srcReader.readLine())!=null)
				destWriter.write("Hello");
			System.out.println("File written on "+toFile.getAbsolutePath());
		}
	}
}
}


