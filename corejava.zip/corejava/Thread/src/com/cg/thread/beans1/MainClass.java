package com.cg.thread.beans1;

public class MainClass {
	public static void main(String args[]) {
	OddEven oddEven=new OddEven();
		Thread th1=new Thread(oddEven,"Even");
		th1.start();
		Thread th2=new Thread(oddEven,"Odd");
		th2.start();
			
		
	}

}
