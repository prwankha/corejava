package com.cg.thread.beans;

public class MyThread extends Thread {

}
