package date;

import java.time.*;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class LocalDate {  
	public static void main(String args[]) {
	Calendar LocalDate = new GregorianCalendar(1955, Calendar.JANUARY, 10);
	Calendar today = new GregorianCalendar(2018, Calendar.DECEMBER, 15); 
	today.setTime(new Date());
	int yearsInBetween = today.get(Calendar.YEAR) - LocalDate.get(Calendar.YEAR); 
	int monthsDiff = today.get(Calendar.MONTH) - LocalDate.get(Calendar.MONTH); 
	int dayofMonth=today.get(Calendar.DAY_OF_MONTH)-LocalDate.get(Calendar.DAY_OF_MONTH);
	System.out.println("number of years : " + yearsInBetween);
	System.out.println("number of months : " + monthsDiff);
	System.out.println("number of days : " + dayofMonth);
	}
}