package com.cg.banking.client;
import com.cg.banking.bean.*;

public class MainClass {

	public static void main(String[] args) {
	Transaction[] transaction=new Transaction[]{
			new Transaction("1111", "credit", "aaaa", 1100.00),
			new Transaction("2222", "credit", "bbb", 1200.00),
			new Transaction("1133", "debit", "ccc", 1300.00)
			};
			
	Transaction[] transaction1=new Transaction[] {
			new Transaction("1122", "debit", "dddd",1111.00), 
			new Transaction("2233", "credit", "eee", 1234.00)};
	
	Transaction[] transaction2=new Transaction[] {
			new Transaction("123", "debit", "aab", 100.00)};
	
	Account [] account=new Account[] {
		new Account(9877, 10000, transaction),
		new Account(111, 2345, transaction1),
		new Account(1112344, 10000, transaction2)};

	Customer[] customers=new Customer[] {
			new Customer(111, 444566, "prajwal", "wankhade","asdfvd",account)
		};
for (Customer customer2 : customers) {
	System.out.println(customer2);
	
}
	}
	

}


