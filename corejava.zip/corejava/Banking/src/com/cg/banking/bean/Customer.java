package com.cg.banking.bean;

import java.util.Arrays;

public class Customer {
	private int customerID,customermobNo;
	private String customerfirstName,customerLastName,customerAddress;
	Account[] account;
	public Customer() {}
	public Customer(int customerID, int customermobNo, String customerfirstName, String customerLastName, String customerAddress, Account[] account) {
		super();
		this.customerID = customerID;
		this.customermobNo = customermobNo;
		this.customerfirstName = customerfirstName;
		this.customerLastName = customerLastName;
		this.customerAddress = customerAddress;
		this.account = account;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public int getCustomermobNo() {
		return customermobNo;
	}
	public void setCustomermobNo(int customermobNo) {
		this.customermobNo = customermobNo;
	}
	public String getCustomerfirstName() {
		return customerfirstName;
	}
	public void setCustomerfirstName(String customerfirstName) {
		this.customerfirstName = customerfirstName;
	}
	public String getCustomerLastName() {
		return customerLastName;
	}
	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public Account[] getAccount() {
		return account;
	}
	public void setAccount(Account[] account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", customermobNo=" + customermobNo + ", customerfirstName="
				+ customerfirstName + ", customerLastName=" + customerLastName + ", customerAddress=" + customerAddress
				+ ", account=" + Arrays.toString(account) + "]";
	}
	
	
}

