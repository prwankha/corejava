package com.cg.banking.bean;

public class Account {
	private int accountNo,accountBal;
	Transaction[] transaction;
	public Account(){}
	public Account(int accountNo, int accountBal, Transaction[] transaction) {
		super();
		this.accountNo = accountNo;
		this.accountBal = accountBal;
		this.transaction = transaction;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public int getAccountBal() {
		return accountBal;
	}
	public void setAccountBal(int accountBal) {
		this.accountBal = accountBal;
	}
	public Transaction[] getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction[] transaction) {
		this.transaction = transaction;
	}
}