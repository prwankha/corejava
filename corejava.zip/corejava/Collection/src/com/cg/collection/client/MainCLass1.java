package com.cg.collection.client;
import com.cg.collection.bean.*;

import java.util.ArrayList;
import java.util.stream.Stream;

public class MainCLass1 {

	public static void main(String[] args) {
		ArrayList<Associate> ascList = new ArrayList<>();
		ascList.add(new Associate( "tanuj", "kumar",101, 15000));
		ascList.add(new Associate( "prajwal", "singh",102, 17000));
		ascList.add(new Associate( "Chetan", "pal", 103,25000));
		ascList.add(new Associate( "prajwal", "singh",102, 17000));
		/*1st way
		Stream<Associate> stream1=ascList.stream();
		Stream<Associate> stream2=stream1.distinct();
		Stream<Associate> stream3=stream2.filter((associate)->associate.getFirstName().startsWith("p"));
		System.out.println(stream3.count());
		stream3.forEach(associate->System.out.println(associate));
		*/
		
		/*2nd way*/
		ascList.stream()
		.distinct()
		.filter(associate->associate.getFirstName().startsWith("p"))
		.forEach(associate->System.out.println(associate));
		
		System.out.println(ascList.stream().map(associate->associate.getAssociateId()));
		
	}

}
