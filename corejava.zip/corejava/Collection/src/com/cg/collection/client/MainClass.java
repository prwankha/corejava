package com.cg.collection.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.function.Consumer;
import java.util.function.Predicate;

import com.cg.collection.bean.*;

public class MainClass {
	public static void main(String args[]) {

		/*FunctionalInterface1 ref1=(firstName,lastName)->System.out.println("GoodMorning" +firstName+ " "+lastName);
	ref1.greetUser("aaa", "bbb");*/

		/*FunctionalInterface2 ref2=(a,b)->a+b;
	System.out.println(ref2.add(100,200));*/

		/*callForWork(()->System.out.println("Hello Raju bhau"));
}
public static void callForWork(Service service) {
	service.doSomeWork();
}

Runnable resourceResources=()->{
	for(int i=1;i<10;i++)
		System.out.println("Tick"+i);
};
Thread th1=new Thread(resourceResources);
th1.start();

Thread th2=new Thread()->{
	for(int i=1;i<10;i++)
		System.out.println("Tick"+i);
}};
th2.start();
	new Thread(()->{
		for(int i=1;i<10;i++)
			System.out.println("Tick"+i);
}).start();*/
		/*java7WayImpl();
		 * java8WayImpl();
		 */

		ArrayList<Associate> ascList = new ArrayList<>();
		ascList.add(new Associate( "tanuj", "kumar",101, 15000));
		ascList.add(new Associate( "prajwal", "singh",102, 17000));
		ascList.add(new Associate( "Chetan", "pal", 103,25000));

		Collections.sort(ascList,(asc1,asc2)->asc1.getAssociateId()-asc2.getAssociateId());
		CheckAssociate c=((asc1)->asc1.getFirstName().startsWith("t"));
		printAssociateDetails(ascList, (a1)->a1.getFirstName().startsWith("t"),(a1)-> System.out.println(a1));

		ascList.forEach((asc1)->System.out.println(asc1));

	}	
	public static void callForWork(Service service) {
        service.doWork();
    }

	@FunctionalInterface
	private interface Condition<T>
	{
		boolean checkNameStartWith(T asc1);
	}
	private static void printAssociateDetails(ArrayList<Associate> associates, Predicate<Associate> predicate,Consumer<Associate> consumer) {
		for(Associate associate: associates)
			if(predicate.test(associate))
				consumer.accept(associate);


	}
}


