package com.cg.collection.client;
import com.cg.collection.bean.AssociateComparator;

import com.cg.collection.bean.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
public class MapDemo {
		private static int Integer = 0;

		public static void main(String args[]) {
			HashMap<Integer, Associate> associate=new HashMap<>();
			//insert
			associate.put(new Integer(0) ,new Associate("aaa", "www", 1111, 11000));
			associate.put(new Integer(1),new Associate("aab", "aww", 2111, 13000));
			associate.put(new Integer(2),new Associate("aac", "wsw", 1311, 12000));
			//search
			Associate associateToBeSearch=new Associate("aac", "wsw", 1311, 12000);
			associate.get(associateToBeSearch);
			System.out.println();
			//remove
			associate.remove(associate.get(associateToBeSearch));
			//sort
			sortbykey(Integer);
			System.out.println(associate);
			
			
		
				
			
			
			
		
		}

		private static void sortbykey(int integer2) {
					
		}

		private static void sortbykey(String integer2) {
			
		}
	}



