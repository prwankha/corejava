package com.cg.collection.client;

public interface Service {
void doWork();
}
