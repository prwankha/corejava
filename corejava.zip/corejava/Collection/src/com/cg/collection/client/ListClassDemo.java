package com.cg.collection.client;
import com.cg.collection.bean.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ListClassDemo {
	public static void main(String args[]) {
		ArrayList<Associate>associate=new ArrayList<>();
		//insert
		associate.add(new Associate("aaa", "www", 1111, 11000));
		associate.add(new Associate("aab", "aww", 2111, 13000));
		associate.add(new Associate("aac", "wsw", 1311, 12000));
		//search
		/*Associate associateToBeSearch=new Associate("aac", "wsw", 1311, 12000);
		int idx=associate.indexOf(associateToBeSearch);
		System.out.println(idx);
		//remove
		associate.remove(associate.indexOf(associateToBeSearch));
		*///sort
		Collections.sort(associate, (asc1,asc2)->asc1.getAssociateId()-asc2.getAssociateId());
		System.out.println(associate);
	
		
		
	
	}
}
