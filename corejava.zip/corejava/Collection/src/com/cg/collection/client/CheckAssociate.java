package com.cg.collection.client;

@FunctionalInterface
public interface CheckAssociate {
	public boolean startWith(Associate assoicate);
}
