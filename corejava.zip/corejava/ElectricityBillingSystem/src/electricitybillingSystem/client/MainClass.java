package electricitybillingSystem.client;

import java.util.Scanner;
import electricbillSystem.services.ElectricBillServicesImpl;
public class MainClass {
    public static void main(String[] args) {
        int pinCode,fromUnits,toUnits,ch=0;
        String firstName,lastName,mobileNo,emailId,fatherName,city,boardName,state,mobileno;
        ElectricBillServicesImpl billService  =new ElectricBillServicesImpl();
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.println("--------------------------------------");
            System.out.println(" 1. Make User. \n 2. Make new Bill. \n 3. View Bill \n 4. Update User Details \n 5. Exit");
            System.out.println("--------------------------------------");
            System.out.println("Enter your choice.");
            ch = scanner.nextInt();
            scanner.nextLine();
            switch (ch) {
            case 1:
                        System.out.print("\nEnter First Name");
                        firstName=scanner.nextLine();
                        System.out.print("Enter Last Name");
                        lastName=scanner.nextLine();
                        System.out.print("Enter father Name");
                        fatherName=scanner.nextLine();
                        System.out.println("Enter Email ID");
                        emailId=scanner.nextLine();
                        System.out.println("Enter Mobile no");
                        mobileNo=scanner.nextLine();
                        System.out.println("Enter Board Name.");
                        boardName = scanner.nextLine();
                        System.out.println("Enter City");
                        city=scanner.nextLine();
                        System.out.println("Enter State");
                        state=scanner.nextLine();
                        System.out.println("Enter PIN CODE");
                        pinCode=scanner.nextInt();                  
                        int accountId= billService.acceptUserDetails(firstName, lastName, mobileNo, emailId, fatherName, pinCode, city,state, boardName); 
                        System.out.println("Account is succesfully generated.\n Account id : "+accountId);
                        scanner.close();
                        break;
            case 2:
                        System.out.println("Enter Previous Bill Units");
                        fromUnits=scanner.nextInt();
                        System.out.println("Enter Current Bill Units");
                        toUnits=scanner.nextInt();  
                        scanner.close();
            default:
                        System.out.println("Not A Valid Choice.");
                        break;
            }//end of switch
        }while(ch!=5);//end of do-while
    }//end of main method
}//end of class
