package com.cg.electricbillSystem.util;

import java.util.HashMap;

import com.cg.electricbillSystem.bean.Customer;
import com.cg.electricbillSystem.bean.ElectricBill;

public class ElectricBillUtil {
    private static int USER_ID_COUNTER,BILL_ID_COUNTER,BILL_IDX = 0;
    public static HashMap<Integer, Customer> customer=new HashMap<>();
    public static HashMap<Customer, ElectricBill> electricbill=new HashMap<>();
    public static int getUSER_ID_COUNTER() {
        return USER_ID_COUNTER;
    }
    public static int getBILL_ID_COUNTER() {
        return BILL_ID_COUNTER;
    }
    public static int getBILL_IDX() {
        return BILL_IDX;
    }
}
