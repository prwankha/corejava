package com.cg.electricbillSystem.DaoServices;

import java.util.List;
import com.cg.electricbillSystem.bean.*;
public interface ElectricityBillDaoService {
    int save(Customer customer) ;
    int saveBill(ElectricBill electricBill);
    boolean update(Customer customer);
    Customer findOne(int userId);
    List<Customer> findAll();
}





