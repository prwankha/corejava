package com.cg.electricbillSystem.DaoServices;

import java.util.List;
import java.util.ArrayList;
import com.cg.electricbillSystem.bean.Customer;
import com.cg.electricbillSystem.bean.ElectricBill;
import com.cg.electricbillSystem.util.ElectricBillUtil;
public class ElectricityBillDaoServicesImpl implements ElectricityBillDaoService{
    @Override
    public int save(Customer customer) {
        customer.setAccountId(ElectricBillUtil.getBILL_ID_COUNTER());
        ElectricBillUtil.customer.put(customer.getAccountId(), customer);
        return customer.getAccountId();
    }
    @Override
    public int saveBill(ElectricBill electricBill) {
        
        return 0;
    }
    @Override
    public boolean update(Customer customer) {
        return true;
    }
    @Override
    public Customer findOne(int userId) {
        return ElectricBillUtil.customer.get(userId);
    }
    @Override
    public List<Customer> findAll() {
        return new ArrayList<>(ElectricBillUtil.customer.values());
    }
}
