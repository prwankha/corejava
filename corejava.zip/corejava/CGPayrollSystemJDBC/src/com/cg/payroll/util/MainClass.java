package com.cg.payroll.util;

import java.io.IOException;
import java.sql.SQLException;

public class MainClass {

	public static void main(String[] args)  {
		try {
			DBUtil.getDBConnection();
			System.out.println("Connection open");
		} catch (IOException |ClassNotFoundException| SQLException e) {
			
			e.printStackTrace();
		}

	}

}
