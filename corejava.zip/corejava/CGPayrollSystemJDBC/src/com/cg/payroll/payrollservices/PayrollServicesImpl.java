package com.cg.payroll.payrollservices;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;


public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
		associateDAO=new AssociateDAOImpl();
	}
	
	

	public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}



	@Override
	public int acceptAssociatedetails(String firstName, String lastName, int yearlyInvestmentUnder80C,
			String department, String designation, String pancard, String emailId, int basicPay, int epf, int pf,
			int accountNo, String ifsc, String bankName) {
		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicPay, pf, epf), new BankDetails(accountNo, ifsc, bankName));
		try {
			associate = associateDAO.save(associate);
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		return associate.getAssociateID();
	}
	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, SQLException{
		Associate associate=this.getAssociateDetails(associateId);
		int annualTax=0;
		int basicSalary= associate.getSalary().getBasicpay();
		int hra  = basicSalary*40/100;
		int oa=basicSalary*20/100;
		int pa=basicSalary*20/100;
		int ca=basicSalary*30/100;
		int pf=associate.getSalary().getPf();
		int epf=associate.getSalary().getEpf();
		int grossSalary=basicSalary+hra+oa+pa+ca;
		int annualSalary=grossSalary*12;
		int Taxable=annualSalary-associate.getYearlyInvestmentUnder80C()-(epf*12)-(pf*12);
		if(Taxable<=250000)
			annualTax=0;
		if(Taxable>250000 && Taxable<=500000) 
			annualTax = ((Taxable-250000)*10)/100+annualTax;
		if(Taxable>500000&&Taxable<=1000000) 
			annualTax = ((Taxable-500000)*20)/100+25000;
		if(Taxable>1000000)
			annualTax=((Taxable-1000000)*30)/100+125000;
		int monthlyTax=annualTax/12;
		int netSalary=grossSalary-epf-pf-monthlyTax;
		return netSalary;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException, SQLException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("associate detail not found for associateId"+associate);
		return associate;
	}
	@Override
	public List getAllAssociatesDetails() throws SQLException {
		return associateDAO.findAll();
	}

}
