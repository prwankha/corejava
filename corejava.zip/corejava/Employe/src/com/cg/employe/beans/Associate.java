package com.cg.employe.beans;

import com.cg.payroll.beans.Bank;
import com.cg.payroll.beans.Salary;

public class Associate {

		private String firstName,lastName;
		Salary salary;
		Bank bankdetail;
		public Associate() {}
		public Associate(String firstName, String lastName, Salary salary, Bank bankdetail) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.salary = salary;
			this.bankdetail = bankdetail;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public Salary getSalary() {
			return salary;
		}
		public void setSalary(Salary salary) {
			this.salary = salary;
		}
		public Bank getBankdetail() {
			return bankdetail;
		}
		public void setBankdetail(Bank bankdetail) {
			this.bankdetail = bankdetail;
		}
}


