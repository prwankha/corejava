package com.cg.inherit.beans;

public class Pemploye extends Employe {
	private int hra,ta,da;
	

	public Pemploye() {
		super();
		}

	public Pemploye(int employeId, int totalSalary, int basicSalary, String firstName, String lastName) {
		super(employeId, totalSalary, basicSalary, firstName, lastName);
}

	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}
public void calculateSalary() {
	this.setDa(this.getBasicSalary()*10/100);
	this.setHra(this.getBasicSalary()*8/100);
	this.setTa(this.getBasicSalary()*7/100);
	this.setTotalSalary(this.getBasicSalary()+this.getHra()+this.getDa()+this.getTa());
	
	
}

@Override
public String toString() {
	return super.toString() + hra + ", ta=" + ta + ", da=" + da ;
}

}
