package com.cg.inherit.beans;

public abstract class Employe {
	private int employeId,totalSalary,basicSalary;
	private String firstName,lastName;
	public Employe() {}
	public Employe(int employeId, int totalSalary, int basicSalary, String firstName, String lastName) {
		super();
		this.employeId = employeId;
		this.totalSalary = totalSalary;
		this.basicSalary = basicSalary;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public int getEmployeId() {
		return employeId;
	}
	public void setEmployeId(int employeId) {
		this.employeId = employeId;
	}
	public int getTotalSalary() {
		return totalSalary;
	}
	public void setTotalSalary(int totalSalary) {
		this.totalSalary = totalSalary;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public abstract void calculateSalary();
	@Override
	public String toString() {
		return "Employe [employeId=" + employeId + ", totalSalary=" + totalSalary + ", basicSalary=" + basicSalary
				+ ", firstName=" + firstName + ", lastName=" + lastName + "]";
	}

}

