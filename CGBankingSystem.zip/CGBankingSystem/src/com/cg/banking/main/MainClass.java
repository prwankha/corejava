package com.cg.banking.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws AccountNotFoundException, AccountBlockedException {
		BankingServices bankingServices=new BankingServicesImpl();
		Scanner scanner=new Scanner(System.in);
		int choice,pinNumber = 0;
		long accountNoTo,accountNoFrom,accountNo;
		float balance,amount,initBalance,transferAmount;
		String accountType,status;
		try {
			do {
				System.out.println("\n Enter your choice :");
				System.out.println(" 1. Open Account");
				System.out.println(" 2. Deposit Amountt");
				System.out.println(" 3. Withdraw Amount");
				System.out.println(" 4. Fund Transfer");
				System.out.println(" 5. Get Account Detail");
				System.out.println(" 6. Get All Account Detail");
				System.out.println(" 7. Get Account All Transaction Detail");
				System.out.println(" 8. Get Account Status");
				System.out.println(" 9. Pdf generator");
				System.out.println("10. Exit");
				choice = scanner.nextInt();
				scanner.nextLine();
				switch(choice) {
				case 1:
					System.out.print("Enter account Type :");
					accountType = scanner.nextLine();
					System.out.print("Enter initBalance :");
					initBalance = scanner.nextFloat();
					Account account = bankingServices.openAccount(accountType, initBalance);
					System.out.print("Account opened sucessfully\n Your account no. is :"+account.getAccountNo()+"\nyour pin is : "+account.getPinNumber()+"\n your current Bal :"+account.getAccountBalance());
					break;
				case 2:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount :");
					amount=scanner.nextFloat();
					balance=bankingServices.depositAmount(accountNo, amount);
					System.out.println("Amount deposited sucessfully\n Available balance is :"+balance);
					break;
				case 3:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount :");
					amount=scanner.nextFloat();
					System.out.println("Enter pinNumber :");
					pinNumber=scanner.nextInt();
					amount=bankingServices.withdrawAmount(accountNo, amount, pinNumber);
					System.out.println("Amount withdraw sucessfully\n Available balance is :"+amount);
					break;
				case 4:
					System.out.println("Enter accountNoTo :");
					accountNoTo=scanner.nextLong();
					System.out.println("Enter accountNoFrom :");
					accountNoFrom=scanner.nextLong();
					System.out.println("Enter transferAmount :");
					transferAmount=scanner.nextFloat();
					System.out.println("Enter pinNumber :");
					pinNumber=scanner.nextInt();
					balance=bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
					System.out.println("Fund Transfer Sucessfully.\n Available Bal : "+balance);
					break;
				case 5:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					Account account1=bankingServices.getAccountDetails(accountNo);
					System.out.println(account1.toString());
					//System.out.println("Account Details are : \n Account Bal : "+account1.getAccountBalance()+"\n Account Type : "+account1.getAccountType()+"\n Pin Number : "+ account1.getPinNumber()+"\n Status : "+account1.getStatus());
					break;
				case 6:
					List<Account> aList= new ArrayList<>();
					aList= bankingServices.getAllAccountDetails();
					System.out.println("All Account Details are :");
					for (Account account2 : aList) {
						System.out.println(account2.toString());
					}
					break;
				case 7:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					List<Transaction>tList=new ArrayList<>();
					tList=bankingServices.getAccountAllTransaction(accountNo);
					System.out.println(" All Transactions are :"+tList);
					break;
				case 8:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					status=bankingServices.accountStatus(accountNo);
					System.out.println("Account status :"+status);
					break;
				case 9:
					System.out.println("Enter accountNo :");
					accountNo=scanner.nextLong();
					bankingServices.pdfGenerator(accountNo);
					System.out.println("Pdf generated sucessfully.");
					break;
				case 10:
					System.out.println("Thank you");
					System.exit(0);
				default:
					System.out.println("Enter valid choice.");
				}
			}while(choice!=10);
		}	catch(Exception e) {
			e.printStackTrace();
		}


	}
}




