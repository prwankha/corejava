package com.cg.banking.services;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

public class BankingServicesImpl implements BankingServices {
	AccountDAO accountDAO=new AccountDAOImpl();
	TransactionDAO transactionDAO=new TransactionDAOImpl();

	@Override
	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		//Account type
		Account account=new Account();
		if(!(accountType.equals("Salary")
				||accountType.equals("Saving")||accountType.equals("Current"))) throw	new InvalidAccountTypeException();
		//intial balance
		if(initBalance<=500)throw new InvalidAmountException();
		account.setAccountType(accountType);
		account.setAccountBalance(initBalance);
		//Pin generation
		account.setPinNumber(Integer.parseInt(String.format("%04d", new Random().nextInt(8999)+1000)));
		account.setStatus("Active");
		accountDAO.save(account);
		transactionDAO.save(new Transaction(initBalance, "Credit", account));
		return account;
	}
	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException();
		if(!account.getStatus().equals("Active")) throw new AccountBlockedException();
		account.setAccountBalance(account.getAccountBalance()+amount);
		Transaction transaction=new Transaction(amount, "Credit", account);
		transactionDAO.save(transaction);
		accountDAO.update(account);
		return account.getAccountBalance() ;
	}
	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException();  
		if(account.getAccountBalance()<amount)throw new InsufficientAmountException();
		if(account.getPinNumber()!=pinNumber)throw new InvalidPinNumberException();
		if(!account.getStatus().equals("Active"))throw new AccountBlockedException();
		account.setAccountBalance(account.getAccountBalance()-amount);
		Transaction transaction=new Transaction(amount, "Debit", account);
		transactionDAO.save(transaction);
		accountDAO.update(account);
		return account.getAccountBalance();
	}
	@Override
	public float fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {

		Account accountTo=accountDAO.findOne(accountNoTo);
		Account accountFrom=accountDAO.findOne(accountNoFrom);
		if(accountTo==null||accountFrom==null)throw new AccountNotFoundException();
		if(!accountTo.getStatus().equalsIgnoreCase("Active")||!accountFrom.getStatus().equalsIgnoreCase("Active"))throw new AccountBlockedException();
		if(accountFrom.getPinNumber()!=pinNumber)throw new InvalidPinNumberException();
		if(accountTo.getAccountBalance()-transferAmount<=500)throw new InsufficientAmountException();
		accountTo.setAccountBalance(accountTo.getAccountBalance()+transferAmount);
		accountFrom.setAccountBalance(accountFrom.getAccountBalance()-transferAmount);
		Transaction transactionFrom=new Transaction(transferAmount, "Debit", accountFrom);
		Transaction transactionTo=new Transaction(transferAmount, "Credit", accountTo);
		transactionDAO.save(transactionFrom);
		transactionDAO.save(transactionTo);
		accountDAO.update(accountTo);
		accountDAO.update(accountFrom);
		return accountFrom.getAccountBalance();
	}
	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException();
		return account;
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		if(accountDAO.findAll()==null)throw new BankingServicesDownException();
		return accountDAO.findAll();
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException();
		return transactionDAO.findAll(accountNo);
	}
	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=accountDAO.findOne(accountNo);
		if(account==null)throw new AccountNotFoundException();
		if (!account.getStatus().equalsIgnoreCase("active"))
			throw new AccountBlockedException();
		return account.getStatus();
	}
	@Override
	public void pdfGenerator(long accountNo) throws FileNotFoundException, DocumentException, BankingServicesDownException, AccountNotFoundException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("Transactions.pdf"));
        document.open();
        document.add(new Paragraph("Transactions: "));
        com.itextpdf.text.List orderedList = new com.itextpdf.text.List(com.itextpdf.text.List.ORDERED);
        document.add(orderedList);
        for(Transaction t: new ArrayList<>(getAccountAllTransaction(accountNo))) {
            orderedList.add(t.toString());
        }
        document.add(orderedList);
        document.close();
        writer.close();
        
    }


}
