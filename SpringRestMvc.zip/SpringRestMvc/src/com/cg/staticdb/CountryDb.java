package com.cg.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Country;

public class CountryDb {
	private static ArrayList<Country> countryList=new ArrayList<Country>();
	static {
		countryList.add(new Country("1001", "India","123456"));
		countryList.add(new Country("1002", "Pak","213456"));
		countryList.add(new Country("1003", "SriLanka","313456"));
		countryList.add(new Country("1004", "China","413456"));
		countryList.add(new Country("1005", "Usa","513456"));
	}
	public static ArrayList<Country> getCountryList() {
		return countryList;
	}
	public static void setCountryList(ArrayList<Country> countryList) {
		CountryDb.countryList = countryList;
	}

}
