package com.cg.dao;
import java.util.List;
import javax.xml.ws.RespectBinding;
import org.springframework.stereotype.Repository;
import com.cg.bean.Country;
import com.cg.staticdb.CountryDb;

@Repository
public class CountryDaoImpl  implements ICountryDao{

	@Override
	public List<Country> getAllCountries() {
		return CountryDb.getCountryList();
	}

	@Override
	public void addCountry(Country country) {
		CountryDb.getCountryList().add(country);
		
	}

	@Override
	public Country deleteCountry(int id) {
		return CountryDb.getCountryList().remove(id);
	}

	@Override
	public Country searchCountry(int id) {
		return CountryDb.getCountryList().stream().filter(c->Integer.parseInt(c.getCountryId())==id).findFirst().get();
		
	}

}
